<?php 
session_start();


include "koneksi.php";
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
$sql = "SELECT * FROM post order by no desc" ;
$query = mysqli_query($koneksi,$sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <link rel=”stylesheet” href=”https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css”>
    <style>
       body{
       
        background-image: url(images/bg2.jpg);
        background-size: cover;
        background-repeat:no-repeat;


      }
        .card-img-top {
            transition: transform 0.3s; 
        }
        .card-img-top:hover {
            transform: scale(1.2);
        }
      
    </style>
  </head>
<body>


<nav class="navbar fixed-top" style="background-color: #ae6a4b">
<ul class="nav nav-tabs">
  <li class="nav-item" >
  <div class="container-fluid">
      	
<div class="lingkaran1">
  <a class = "navbar-brand" href = "logo3.png">
  <img src = "images/logo3.png" weight="100" height = "50" style="border-radius: 50%;">
    </a>
  </li>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled fw-bold" aria-disabled="true">𝖆𝖓𝖎𝖒𝖆𝖑 𝖜𝖔𝖗𝖑𝖉</a>
  </li>
  
</ul>
<span>
      <button type="button" class="btn btn-info bi bi-plus-square" data-bs-toggle="modal" data-bs-target="#exampleModal"></button>
      <a href="logout.php"><button class="btn btn-dark"><i class="bi bi-arrow-right-square"></i></button></a>
              </span>
      </div>
  </div>
</nav> <br>


<div class= "container mt-5"><br>
    <!-- <h1 style="text-align: center:">Instagram Pet</h1><br><br> -->
  
    <?php while ($post = mysqli_fetch_assoc($query)) { ?>
      <center>
      <!-- <div class="card" >
  <img class="card-img-top" src="..." alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div> -->
    <div class="card" style="width: 400px;">
      <img src="images/<?= $post['gambar'] ?>" alt="" class="card-img-top" alt="snow">
      <div class="card-body">
    <h5 class="card-title"><?= $post['capt'] ?></h5>
    <p class="card-text"><?= $post['lokasi'] ?></p>
    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no'] ?>"><span class="fa fa-edit"></span></button>
    <a href="hapus.php?no=<?= $post['no'] ?>"><button class="btn btn-info"><li class="fa fa-trash-can" style="font-size:20px"></li></button></a>
  </div>
  </div>

<br><br> </center>

<div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">

        <div class="modal-content" style="background-color: #ae6a4b">

            <div class="modal-header">
            <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
            <h3 class="modal-title" id="staticBackdropLabel">𝕰𝖉𝖎𝖙 𝕻𝖔𝖘𝖙𝖎𝖓𝖌𝖆𝖓</h3><br>

            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>   
            </div>
            <div class="container">
            <form action="proses_edit.php" method="post" 
    enctype="multipart/form-data">
    
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
        
        <div class="form-group">
        <label for="">𝕲𝖆𝖒𝖇𝖆𝖗</label>
        <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>" ><br>
        <img src="images/<?= $post['gambar'] ?>" width="100" alt="" ><br>
        </div><br>

        <div class="form-group">
        <label for="">𝕮𝖆𝖕𝖙𝖎𝖔𝖓</label>
        <input type="text" name="capt" id="" class="form-control" value="<?= $post['capt'] ?>" autocomplete="off"><br>
        </div><br>

        <div class="form-group">
        <label for="">𝕷𝖔𝖐𝖆𝖘𝖎</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        </div><br>

        <input type="submit" value="𝖀𝖕𝖉𝖆𝖙𝖊" class="btn btn-outline-info" name="update">
    </form>
        </div>
      </div>
        </div>
        </div>      
    
     


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" >
  <div class="modal-dialog" >
    <div class="modal-content" style="background-color: #ae6a4b" >
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">𝕱𝖔𝖗𝖒 𝕿𝖆𝖒𝖇𝖆𝖍</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">𝕲𝖆𝖒𝖇𝖆𝖗</label>
        <input type="file" name="gambar" class="form-control" required><br>

        <label for="">𝕮𝖆𝖕𝖙𝖎𝖔𝖓</label>
        <input type="text" name="capt" class="form-control"autocomplete="off"><br>

        <label for="">𝕷𝖔𝖐𝖆𝖘𝖎</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off"><br>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">𝕮𝖑𝖔𝖘𝖊</button>
      <input class="btn btn-info" type="submit" value="simpan" name="simpan">
        </div>
        </form>
       
        
    

    </div>
    </div>
  </div>
</div>
<?php

} ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
   
  </body>
</html>