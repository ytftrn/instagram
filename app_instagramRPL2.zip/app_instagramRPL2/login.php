<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	  <link rel="stylesheet" href="login.css">
    <style>
       body{
       
        background-image: url(images/bg2.jpg);
        background-size: cover;
        background-repeat:no-repeat;


      }
        .card-img-top {
            transition: transform 0.3s; 
        }
        .card-img-top:hover {
            transform: scale(1.1);
        }
      
    </style>
	<title>Document</title>
</head>
<body>
	
<div class="container">
        <div class="login">
            <form action="proses_login.php" method="post">
                <h1>𝕷𝖔𝖌𝖎𝖓</h1>
                <hr>
                <p></p>
                <label for="">𝖀𝖘𝖊𝖗𝖓𝖆𝖒𝖊</label>
                <input type="text" name="username" placeholder="username">
                <label for="">𝕻𝖆𝖘𝖘𝖜𝖔𝖗𝖉</label>
                <input type="password" name="password" placeholder="Password">
                <button>𝕷𝖔𝖌𝖎𝖓</button>

            </form>
        </div>
        <div class="right">
            <img src="logo3.png" alt="">
        </div>
    </div>
</body>
</html>
