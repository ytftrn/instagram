<?php 
$server = "localhost";
$pengguna = "root";
$password = "123456";
$database = "db_instagram";

$koneksi = mysqli_connect($server,$pengguna,$password,$database);

// if ($koneksi) {
//     echo "berhasil terkoneksi";
// }else{
//     echo "gagal terkoneksi";
// }
?>